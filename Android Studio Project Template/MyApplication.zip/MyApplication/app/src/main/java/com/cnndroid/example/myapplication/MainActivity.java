package com.cnndroid.example.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.renderscript.RenderScript;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import network.CNNdroid;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            // 1) Create a Renderscript object
            Thread.sleep(10000);
            RenderScript myRenderScript = RenderScript.create(this);

            // 2) Construct a CNNdroid object
            //	  and provide NetFile location address.
            String NetFile = "/sdcard/Data_ImageNet2012/AlexNet_def.txt";
            CNNdroid myCNN = new CNNdroid(myRenderScript, NetFile);

            // 3) Prepare your input to the network.
            //		(The input can be single or batch of images.)
            float[][][]  inputSingle = new float[3][128][128];
            float[][][][] inputBatch = new float[16][3][227][227];

            // 4) Call the Compute function of the CNNdroid library
            //    and get the result of the CNN execution as an Object
            //	  when the computation is finished.


            Object output = myCNN.compute(inputSingle);
            long runTime = System.currentTimeMillis();
            for(int i = 0; i < 100; i++){
                output = myCNN.compute(inputSingle);
            }
            runTime = System.currentTimeMillis() - runTime;
            Log.d("CNNdroid", "Computation Run Time = " + String.valueOf(runTime) + "ms");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
